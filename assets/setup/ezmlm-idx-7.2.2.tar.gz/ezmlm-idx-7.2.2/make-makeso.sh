echo exec "$LD $LDSO" -L. -o '${1+"$@"}'

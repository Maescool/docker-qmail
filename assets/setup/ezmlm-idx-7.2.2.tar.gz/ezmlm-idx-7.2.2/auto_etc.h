#ifndef AUTO_ETC_H
#define AUTO_ETC_H

extern const char *auto_etc();

#endif

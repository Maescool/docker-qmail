#ifndef AUTO_LIB_H
#define AUTO_LIB_H

extern const char *auto_lib(void);

#endif

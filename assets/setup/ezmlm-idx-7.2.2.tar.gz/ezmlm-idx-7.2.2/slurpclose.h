#ifndef SLURPCLOSE_H
#define SLURPCLOSE_H

extern int slurpclose(int fd,stralloc *sa,int bufsize);

#endif

#ifndef SURF_H
#define SURF_H

#include "uint32.h"
extern void surf(uint32 out[8],const uint32 in[12],const uint32 seed[32]);

#endif

#ifndef AUTO_CRON_H
#define AUTO_CRON_H

extern const char auto_cron[];

#endif

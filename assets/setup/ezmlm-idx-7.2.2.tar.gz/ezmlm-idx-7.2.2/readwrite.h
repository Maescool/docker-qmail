#ifndef READWRITE_H
#define READWRITE_H

#include <sys/types.h>
extern ssize_t read();
extern ssize_t write();

#endif

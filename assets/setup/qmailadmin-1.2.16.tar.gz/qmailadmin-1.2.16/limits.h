/* 
 * $Id: limits.h,v 1.1.2.1 2004-11-20 01:10:41 tomcollins Exp $
 */

#define LIMIT_TOKENS " :\t\r\n"
void load_limits();

#ifndef DNSDOE_H
#define DNSDOE_H

extern void dnsdoe();

#endif

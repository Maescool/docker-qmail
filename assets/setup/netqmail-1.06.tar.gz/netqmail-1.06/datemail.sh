exec QMAIL/bin/predate QMAIL/bin/sendmail ${1+"$@"}

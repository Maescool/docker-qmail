#ifndef AUTO_PATRN_H
#define AUTO_PATRN_H

extern int auto_patrn;

#endif

#ifndef RCPTHOSTS_H
#define RCPTHOSTS_H

extern int rcpthosts_init();
extern int rcpthosts();

#endif
